import 'package:adsl_tci/LoginPage.dart';
import 'package:adsl_tci/Models/bank_redirector_model_entity.dart';
import 'package:adsl_tci/Models/traffic_ditails_model_entity.dart';
import 'package:adsl_tci/Models/traffic_model_entity.dart';
import 'package:adsl_tci/requests/RequestList.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:developer';

import 'package:fluttertoast/fluttertoast.dart';

import 'PaymentPage.dart';

class TrafficPage extends StatefulWidget {
  @override
  _TrafficPageState createState() => _TrafficPageState();
}

class _TrafficPageState extends State<TrafficPage> {
  String selected_bank;
  var bank_kays = [];
  TrafficModelEntity _Traffic = new TrafficModelEntity();
  final GlobalKey<RefreshIndicatorState> _refreshIndicatorKey =
      new GlobalKey<RefreshIndicatorState>();

  @override
  void initState() {
    Startstate();
  }

  Startstate() async {
    _Traffic = await GetTraffic();
    log(_Traffic.toString());
    setState(() {});
  }

  Future<void> _refresh() async {
    _Traffic = await GetTraffic();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(
            appBar: AppBar(),
            body: RefreshIndicator(
              key: _refreshIndicatorKey,
              onRefresh: _refresh,
              child: Center(child: traffic_detail_Content()),
            )));
  }

  traffic_detail_Content() {
    switch (_Traffic.ok) {
      case false:
        {
          if (_Traffic.code == 2) {
            return RaisedButton(
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => LoginPage()));
              },
              child: Text(
                "ورود مجدد",
                style: TextStyle(color: Colors.white),
              ),
              color: Color(0xff1e87f0),
            );
          }
          return RaisedButton(
            onPressed: () async {
              _Traffic = await GetTraffic();

              setState(() {});

              _Traffic = await GetTraffic();

              setState(() {});
            },
            child: Text("تلاش مجدد"),
            color: Color(0xff1e87f0),
          );
        }
        break;
      case true:
        {
          return ListView(shrinkWrap: true, children: <Widget>[items_list()]);
        }
        break;
      default:
        {
          return Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              CircularProgressIndicator(),
              Text("لطفا صبر کنید...")
            ],
          );
        }
    }
  }

  items_list() {
    return Container(
        child: Column(
      children: <Widget>[
        ListView.builder(
            physics: NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            padding: const EdgeInsets.all(8),
            itemCount: _Traffic.result.xList.length,
            itemBuilder: (BuildContext context, int Index) {
              return item(_Traffic.result.xList[Index]);
            })
      ],
    ));
  }

  item(item) {
    return Card(
      child: Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: <Widget>[
            Text(
              (int.parse(item.credit) / 1000).toInt().toString() + " گیگابایت",
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
            ),
            Text(
              item.name,
              textAlign: TextAlign.center,
              style: TextStyle(color: Color(0xff666666)),
            ),
            Text(item.groupName, style: TextStyle(color: Color(0xff32d296))),
            Divider(),
            Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                RaisedButton(
                    color: Color(0xff1e87f0),
                    child: Container(
                      child: Text(
                        "خرید",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                    onPressed: () async {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => PaymentPage()));

//                      showDialog(
//                          context: context, child: new Dialog(item.serial));
                    }),
                Text(
                  item.price + " ریال  ",
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }

//  BankRedirector(service_id, getway) async {
//    BankRedirectorModelEntity _Bank_Redirector;
//    _Bank_Redirector = await GetBankRedirector(service_id, getway);
//  }
}

class Dialog extends StatefulWidget {
  String serial;

  Dialog(this.serial);

  @override
  _DialogState createState() => _DialogState(this.serial);
}

class _DialogState extends State<Dialog> {
  TrafficDitailsModelEntity _Traffic_details = new TrafficDitailsModelEntity();
  BankRedirectorModelEntity BankRedirector;
  bool pay_state = false;
  var Content;
  String order_id = "_";
  String serial;
  String selected_bank;

  _DialogState(this.serial);

  @override
  void initState() {
    StartState();
    // TODO: implement initState
    super.initState();
  }

  StartState() async {
    _Traffic_details = await GetTerafficDitails(serial);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    Content = dialog_content();

    return Directionality(
        textDirection: TextDirection.rtl,
        child: Container(
          margin: EdgeInsets.only(top: 80, bottom: 50, right: 10, left: 10),
          child: Material(
              borderRadius: BorderRadius.all(Radius.circular(5)),
              child: Content),
        ));
  }

  row_text(title, value, {title_color = 0xff333333, rial = false}) {
    var row = Row(
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        Text(
          title + ":     ",
          style: TextStyle(
              color: Color(
                title_color,
              ),
              fontWeight: FontWeight.bold),
        ),
        Flexible(
          child: Text(
            value,
            style: TextStyle(color: Color(0xff666666)),
          ),
        ),
        Text("  ریال"),
      ],
    );

    (rial ? null : row.children.removeLast());
    return row;
  }

  dialog_content() {
    switch (_Traffic_details.ok) {
      case false:
        {
          if (_Traffic_details.code == 2) {
            return RaisedButton(
              onPressed: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => LoginPage()));
              },
              child: Text(
                "ورود مجدد",
                style: TextStyle(color: Colors.white),
              ),
              color: Color(0xff1e87f0),
            );
          }
          return RaisedButton(
            onPressed: () async {
              _Traffic_details = await GetTraffic();

              setState(() {});

              _Traffic_details = await GetTraffic();

              setState(() {});
            },
            child: Text("تلاش مجدد"),
            color: Color(0xff1e87f0),
          );
        }
        break;
      case true:
        {
          return Column(
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Text(
                    "ویژگی‌های سفارش",
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        color: Color(0xff333333)),
                  ),
                  IconButton(
                      icon: Icon(Icons.close),
                      onPressed: () {
                        Navigator.pop(context);
                      })
                ],
              ),
              Divider(),
              SizedBox(
                height: 5,
              ),
              row_text("نام ترافیک", _Traffic_details.result.service.name),
              SizedBox(
                height: 15,
              ),
              row_text("توضیحات",
                  _Traffic_details.result.service.comment.toString()),
              SizedBox(
                height: 15,
              ),
              row_text(
                  "حجم ترافیک",
                  (int.parse(_Traffic_details.result.service.credit) / 1000)
                          .toInt()
                          .toString() +
                      " گیگابایت"),
              Divider(),
              row_text(
                  "اعتبار پنل", _Traffic_details.result.costs.panel.toString(),
                  rial: true, title_color: 0xff32d296),
              Divider(),
              SizedBox(
                height: 15,
              ),
              row_text("قیمت ترافیک",
                  _Traffic_details.result.costs.service.toString(),
                  title_color: 0xff1e87f0, rial: true),
              SizedBox(
                height: 15,
              ),
              row_text("مالیات ارزش افزوده",
                  _Traffic_details.result.costs.tax.toString(),
                  rial: true),
              SizedBox(
                height: 15,
              ),
              row_text("هزینه نهایی + ۹٪",
                  _Traffic_details.result.costs.total.toString(),
                  rial: true, title_color: 0xfffaa05a),
              SizedBox(
                height: 15,
              ),
              Divider(),
              SizedBox(
                height: 15,
              ),
              Text(
                "درگاه پرداخت آنلاین مورد نظر را انتخاب کنید:",
                style: TextStyle(color: Color(0xff666666), fontSize: 20),
              ),
              Expanded(
                  child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[
                  GestureDetector(
                      onTap: () {
                        selected_bank = _Traffic_details.result.banks[0].serial;

                        setState(() {});
                      },
                      child: Container(
                        decoration: (selected_bank ==
                                _Traffic_details.result.banks[0].serial
                            ? BoxDecoration(
                                border: Border.all(color: Color(0xff1e87f0)))
                            : BoxDecoration()),
                        child: Image.network(
                          _Traffic_details.result.banks[0].logo,
                        ),
                      )),
                  GestureDetector(
                      onTap: () {
                        selected_bank = _Traffic_details.result.banks[1].serial;

                        setState(() {});
                      },
                      child: Container(
                        decoration: (selected_bank ==
                                _Traffic_details.result.banks[1].serial
                            ? BoxDecoration(
                                border: Border.all(color: Color(0xff1e87f0)))
                            : BoxDecoration()),
                        child: Image.network(
                          _Traffic_details.result.banks[1].logo,
                        ),
                      )),
                ],
              )),
              row_text("شماره سفارش", order_id),
              RaisedButton(
                onPressed: () async {
                  if (selected_bank == null) {
                    Fluttertoast.showToast(
                        msg: "درگاه پرداخت آنلاین مورد نظر را انتخاب کنید");
                  } else {
                    if (pay_state) {
                      //get pay page
                    } else {
                      BankRedirector = await GetBankRedirector(
                          _Traffic_details.result.service.serial,
                          selected_bank);

                      if (BankRedirector.ok) {
                        order_id = BankRedirector.result.order.toString();
                        pay_state = true;
                      } else {
                        Fluttertoast.showToast(
                            msg: "مشکلی در اتصال به بانک وجود دارد");
                      }
                    }

                    setState(() {});
                  }
//
                },
                child: Text(
                  (pay_state ? "پرداخت" : "ادامه"),
                  style: TextStyle(color: Colors.white),
                ),
                color: Color(0xff1e87f0),
              )
            ],
          );
        }
        break;
      default:
        {
          return Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              CircularProgressIndicator(),
              Text("لطفا صبر کنید...")
            ],
          );
        }
    }
  }
}
