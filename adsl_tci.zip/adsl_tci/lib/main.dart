import 'dart:developer';

import 'package:adsl_tci/TrafficPage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_stetho/flutter_stetho.dart';

import 'HomePage.dart';
import 'LoginPage.dart';

void main() {
  Stetho.initialize();
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    theme: ThemeData(fontFamily: 'Samim'),
    home: MainPage(),
  ));
}

class MainPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return TrafficPage();
  }
}
