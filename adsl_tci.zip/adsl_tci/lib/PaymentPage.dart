import 'package:adsl_tci/Urls.dart';
import 'package:flutter/material.dart';
import 'package:flutter_inappwebview/flutter_inappwebview.dart';

class PaymentPage extends StatefulWidget {
  @override
  _PaymentPageState createState() => _PaymentPageState();
}

class _PaymentPageState extends State<PaymentPage> {
  String _loadHTML() {
    return r'''
      <html>
        <body onload="document.f.submit();">
          <form id="f" name="f" method="post" action="YOUR_POST_URL">
            <input type="hidden" name="PARAMETER" value="VALUE" />
          </form>
        </body>
      </html>
    ''';
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        body: Container(
//          child: InAppWebView(
//              initialUrl: "http://google.com",
//              initialHeaders: {},
//              initialOptions: InAppWebViewWidgetOptions()),
            ),
      ),
    );
  }
}
