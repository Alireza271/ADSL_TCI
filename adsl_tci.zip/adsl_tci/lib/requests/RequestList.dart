import 'package:adsl_tci/Models/bank_redirector_model_entity.dart';
import 'package:adsl_tci/Models/traffic_ditails_model_entity.dart';
import 'package:adsl_tci/Models/traffic_model_entity.dart';
import 'package:adsl_tci/requests/Request.dart';

GetTraffic() async {
  Request request = new Request(new TrafficModelEntity(), "GetTrafficList", {
    "filters": {
      "credit": {"mode": "none"}
    }
  });
  TrafficModelEntity response = await request.Response();
  return response;
}

GetTerafficDitails(String service_id) async {
  Request request = new Request(
     new TrafficDitailsModelEntity(), "GetTrafficInvoice", {"service": service_id});
  TrafficDitailsModelEntity response = await request.Response();
  return response;
}

GetBankRedirector(String service_id,getway) async {
  Request request = new Request(
      new BankRedirectorModelEntity(), "RequestBankRedirector", {"service": service_id,"gateway":getway});
  BankRedirectorModelEntity response = await request.Response();
  return response;
}
