import 'dart:convert';
import 'dart:developer';

import 'package:adsl_tci/Models/traffic_ditails_model_entity.dart';
import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../Urls.dart';
import 'Nonce.dart';

class Request {
  var Model;
  String action;
  Map params;

  Request(this.Model, this.action, this.params);

   Response() async {
    Dio dio = new Dio();
    var db = await SharedPreferences.getInstance();
    var _nonce = new Nonce();
    var header = {"cookie": db.getString("cookie")};
    var body = {
      "nonce": await _nonce.GetNonce(),
      "action": this.action,
      "params": this.params
    };
    var response = await dio.post(Urls.traffics,
        data: FormData.fromMap(body), options: Options(headers: header));
    log("d"+response.toString());
    Model.fromJson(json.decode(response.toString()));
    Nonce().SetNonce(Model.nonce);
    log(Model.nonce);
    return Model;
  }
}
