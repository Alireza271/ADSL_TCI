class Urls{
  static const String _host="https://adsl.tci.ir/";
  static const String panel =_host+"panel/";
  static const String login =_host+"panel/login/";
  static const String nonce =_host+"panel/ajax/";
  static const String traffics =_host+"panel/ajax/traffic";
}