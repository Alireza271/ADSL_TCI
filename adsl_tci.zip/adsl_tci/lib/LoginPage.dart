import 'dart:convert';
import 'dart:developer';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:html/parser.dart';
import 'package:http/http.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'HomePage.dart';
import 'Urls.dart';

class LoginPage extends StatefulWidget {
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool login_loading_button = false;
  String login_url;
  String captcha_img_url;
  TextEditingController usernameController = new TextEditingController();
  TextEditingController passwordController = new TextEditingController();
  TextEditingController captchaController = new TextEditingController();
  var db;
  Map<String, String> header;

  initState() {
    super.initState();
    StartState();
  }

  StartState() async {
    db = await SharedPreferences.getInstance();
    usernameController.text = db.getString("username");
    passwordController.text = db.getString("password");
    get_login_page_value();
  }

  Widget build(BuildContext context) {
    final logo = Hero(
      tag: 'hero',
      child: CircleAvatar(backgroundColor: Colors.transparent, radius: 48.0),
    );
    final logo1 = Hero(
      tag: 'hero_1',
      child: CircleAvatar(backgroundColor: Colors.transparent, radius: 48.0),
    );

    final username = TextField(
      controller: usernameController,
      textAlign: TextAlign.center,
      keyboardType: TextInputType.number,
      autofocus: false,
      decoration: InputDecoration(
        hintText: 'نام کاربری',
        contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(32.0)),
      ),
    );

    final password = TextField(
      controller: passwordController,
      keyboardType: TextInputType.visiblePassword,
      textAlign: TextAlign.center,
      autofocus: false,
      obscureText: true,
      decoration: InputDecoration(
        hintText: 'کلمه عبور',
        contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(32.0)),
      ),
    );

    final loginButton = Padding(
      padding: EdgeInsets.symmetric(vertical: 16.0),
      child: RaisedButton(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
        ),
        onPressed: () async {
          login_button_action();
        },
        padding: EdgeInsets.all(12),
        color: Colors.lightBlueAccent,
        child: (login_loading_button
            ? CircularProgressIndicator()
            : Text('ورود', style: TextStyle(color: Colors.white))),
      ),
    );

    final captcha = GestureDetector(
      child: Image.network(
        captcha_img_url + "&date=" + DateTime.now().millisecond.toString(),
        headers: header,
        height: 55,
        loadingBuilder: (BuildContext context, Widget child,
            ImageChunkEvent loadingProgress) {
          if (loadingProgress == null) {
            return child;
          }
          return CircularProgressIndicator();
        },
      ),
      onTap: () {
        setState(() {});
      },
    );

    final captcha_text_fild = TextField(
      controller: captchaController,
      keyboardType: TextInputType.number,
      textAlign: TextAlign.center,
      autofocus: false,
      obscureText: true,
      decoration: InputDecoration(
        hintText: 'عبارت امنیتی',
        contentPadding: EdgeInsets.fromLTRB(20.0, 10.0, 20.0, 10.0),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(32.0)),
      ),
    );

    return Stack(
      children: <Widget>[
//        Image.asset(
//          Res.Bak,
//          height: MediaQuery.of(context).size.height,
//          width: MediaQuery.of(context).size.width,
//          fit: BoxFit.cover,
//        ),
        Scaffold(
          backgroundColor: Colors.white.withOpacity(0.7),
          body: Center(
            child: (login_url != null
                ? ListView(
                    shrinkWrap: true,
                    padding: EdgeInsets.only(left: 24.0, right: 24.0),
                    children: <Widget>[
                      logo,
                      logo1,
                      SizedBox(height: 48.0),
                      username,
                      SizedBox(height: 8.0),
                      password,
                      captcha,
                      captcha_text_fild,
                      loginButton,
                    ],
                  )
                : CircularProgressIndicator()),
          ),
        )
      ],
    );
    return CircularProgressIndicator();
  }

  get_login_page_source() async {
    var response = await get(Urls.panel);
    db.setString("cookie", response.headers["set-cookie"]);
    header = {"cookie": db.getString("cookie")};
    return response.body;
  }

  get_login_page_value() async {
    var source = await get_login_page_source();
    var document = parse(source);
    login_url = document.getElementsByTagName("form")[0].attributes['action'];
    captcha_img_url =
        document.getElementById("loginCaptchaImage").attributes['src'];
    setState(() {
      log(captcha_img_url);
      log(login_url);
    });
  }

  login_button_action() async {
    setState(() {
      login_loading_button = true;
    });
    Map<String, dynamic> data = {
      "redirect": "",
      "username": usernameController.text,
      "password": passwordController.text,
      "captcha": captchaController.text,
      "LoginFromWeb": ""
    };
    var response = await post(login_url, body: data, headers: header);
    log(response.statusCode.toString());
    get_panel_source();
  }

  get_panel_source() async {
    var response = await get(Urls.panel, headers: header);
//    log(response.body.toString());
    List message_row = response.body.toString().split("UIkit.notification(");
    if (message_row.length == 2) {
      message_row = message_row[1].toString().split(");");
      String message_text =
          json.decode(message_row[0])['message'].toString().split(";")[1];
      Fluttertoast.showToast(
          msg: message_text,
          textColor: Colors.white,
          backgroundColor: Color(0xffFF8800));
    } else {
      db.setString("username", usernameController.text);
      db.setString("password", passwordController.text);

      Fluttertoast.showToast(
          msg: "ورود با موفقیت انجام شد!",
          textColor: Colors.white,
          backgroundColor: Color(0xff007E33));
      Navigator.push(
          context, MaterialPageRoute(builder: (context) => HomePage()));
    }
    login_loading_button = false;
    setState(() {});
  }
}
